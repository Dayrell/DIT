<?php
	session_start();
	$_SESSION['admin'] = "admin";
	$username = $_POST['username'];
	$userpass = $_POST['password'];
	
	if($username && $userpass)
	{
		$connect = mysql_connect("localhost", "root", "") or die ("Could not connect");
		mysql_select_db("test") or die ("Couldn't find Database");
	}
	else
	{
		die("Please enter a username and password");
	}
?>