<?php
	$logout = $_POST['logout'];
	session_destroy();
	include('adminindex.php');
exit();
?>