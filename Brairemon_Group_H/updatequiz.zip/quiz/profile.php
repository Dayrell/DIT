<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<ul>
		  <li><a  href="home.php">Home</a></li>
		  <li><a class="active" href="#news">Porfile</a></li>
		  <li><a  href="tutorial.php">Tutorial</a></li>
		  <li><a  href="index.php">Quiz</a></li>
		  <li><a  href="leaderboard.php">Leaderboard</a></li>
		  <li><a  href="main_forum.php">Forums</a></li>
		  <li style="float:right"><a href="#about">About</a></li>
		</ul>
<meta charset="utf-8">
<title>Quiz Page</title>

<body background='plain.jpg'>
<div id="profile">		
	<h1>My Profile:</h1>
	<div class="username">
	<h3>Username:</h3>
	</div>
	<div class="highscore">
	<h3>Highscore:</h3>
</div>
</div>



<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form>



<?php
$value = 50;
$max = 200;
$scale = 2.0;
// Get Percentage out of 100
if ( !empty($max) ) { $percent = ($value * 100) / $max; } 
else { $percent = 0; }
// Limit to 100 percent (if more than the max is allowed)
if ( $percent > 100 ) { $percent = 100; }
?>

<div class="percentbar" style="width:<?php echo round(100 * $scale); ?>px;">
	<div style="width:<?php echo round($percent * $scale); ?>px;"></div>
</div>

<h6>Progress: <?php echo $percent; ?>%</h6>


</body>
</html>