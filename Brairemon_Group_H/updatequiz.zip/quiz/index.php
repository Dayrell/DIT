<?php 
$msg = "";
if(isset($_GET['msg'])){
	$msg = $_GET['msg'];
	$msg = strip_tags($msg);
	$msg = addslashes($msg);
}
?>
<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<title>Quiz</title>
<script>
function startQuiz(url){
	window.location = url;
}


</script>
</head>
<body background="snake.jpg" onLoad="getQuestion()">
		<ul>
		  <li><a  href="home.php">Home</a></li>
		  <li><a href="profile.php">Profile</a></li>
		  <li><a href="tutorial.php">Tutorial</a></li>
		   <li><a class="active" href="index.php">Quiz</a></li>
			<li><a href="leaderboard.php">Leaderboard</a></li>
			<li><a  href="main_forum.php">Forums</a></li>
		  <li style="float:right"><a href="#about">Log Out</a></li>
		  <li style="float:right"><a href="#about">Sign Up</a></li>
		</ul>
	<h3></h3>
	<img src="dit.png" alt="dit logo" style="width:200px;height:200px; margin-left:170px; margin-top:0px;">
<div id="quiz">
	<h2 id="title"> PYTHON QUIZ</h2>
	<p id="quiztext"> Welcome to DIT Python Quiz and Tutorial <br> The Quiz will consist of two types of questions <br>
	True or False and Multiple Choice <br>A time limit of 15 seconds per question is set <br>Your score will be kept in a leaderboard
	<br> you will be competing against each member of your class <br>GOOD LUCK !!!!</p>
	<button id="b1" onClick="startQuiz('quiz.php?question=1')">Start Quiz</button>
</div>
</body>
<footer>
  <p>Posted by: BRAIREMON</p>
  <p>Contact information: <a href="mailto:someone@example.com">
  someone@example.com</a>.</p>
</footer>
</html>