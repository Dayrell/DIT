
<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Quiz</title>
</head>
<body background="viper.jpg"><ul>

		  <li><a class="active" href="home.php">Home</a></li>
		  <li><a  href="profile.php">Profile</a></li>
		  <li><a  href="tutorial.php">Tutorial</a></li>
		  <li><a  href="index.php">Quiz</a></li>
		  <li><a href="leaderboard.php">Leaderboard</a></li>
		  <li><a href="main_forum.php">Forums</a></li>
		  <li><a href="addQuestions.php" id='admin'>Admin</a></li>
		  <li style="float:right"><a href="choice.html">Log Out</a></li>
		  <li style="float:right"><a href="#about">Sign Up</a></li>
		</ul>
	<div id="logo">
		<Img src="dit.png" alt="dit logo" style="float:right;width:300px;height:270px;  margin-top:0px; margin-right:10px;">
		<div id="message">
			<h2 id="wel">Welcome to DIT Python Tutorial & Quiz</h2>
			<p>This website was designed and put together by the five people you will see pictured underneath: <br>
			Ryan McDonnell | Jennifer Mullins | Matheus Connolyn | Fábio Dayrell Rosa | Bilguun Nemekhbaatar
			<br> The website is designed to aid first year DIT students in 
			learning Python programming language<br> Students should go through the Tutorial section before attempting a quiz<br> Students
			will compete against eachother in a weekly quiz set up by a lecturer</p>
			<img src="python1.png" alt="python logo" style="width:190px;height:50px; border-radius: 25px; float:right;">
		</div>
	</div>
	<div id="images";=>
		<img src="ryan.jpg" alt="ryan" style="height:85px; width:87px; float:left;border-radius: 15px;margin-left:10px; margin-top:5px;">
		<img src="jen.jpg" alt="jen" style="height:85px; width:87px; float:left;border-radius: 15px;margin-left:10px; margin-top:5px;">
		<img src="mat.jpg" alt="mat" style="height:85px; width:87px; float:left;border-radius: 15px;margin-left:10px; margin-top:5px;">
		<img src="fab.jpg" alt="fab" style="height:85px; width:87px; float:left;border-radius: 15px;margin-left:10px; margin-top:5px;">
		<img src="bil.jpg" alt="bil" style="height:85px; width:87px; float:left;border-radius: 15px;margin-left:10px; margin-top:5px;">
		
	</div>
</body>
</html>
