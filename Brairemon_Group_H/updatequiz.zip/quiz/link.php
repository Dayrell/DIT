<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>link</title>
</head>
<body>
	<a href='home.php'>Home Page </a>
</body>
</html>