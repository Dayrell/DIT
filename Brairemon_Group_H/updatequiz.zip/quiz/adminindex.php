<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background='login.png'>
	<form  action='logdb.php' method='POST'>
		 <input type='text' name='username' placeholder='Admin ID' style='margin-left:467px; margin-top:398px;'> 
		 <input type='password' name='password' placeholder='password' style='margin-left:17px;'> 
		<input type='submit' value='Log in' style='margin-left:17px;'>
	</form>
</body>
</html>