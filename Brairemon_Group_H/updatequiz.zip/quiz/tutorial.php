<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
 <a href="home.php">Click to go back to Homepage</a>
ojqcowqnc
<div data-role="page" id="pageone">
  <div data-role="header" style="background-color:#333; color:white;">
  <a href="home.php">Click to go back to Homepage</a>
    <h1>Chapter 1 Part 1</h1>
  </div>

  <div data-role="main" class="ui-content" style="width:500px;">
    <p>The Python interpreter is usually installed as /usr/local/bin/python on those machines where it is available; <br>putting /usr/local/bin in your Unix shell’s search path makes it possible to start it by typing the command

python
to the shell. Since the choice of the directory where the interpreter lives is an installation option, other places are possible; check with your local Python guru or system administrator. (E.g., /usr/local/python is a popular alternative location.)

On Windows machines, the Python installation is usually placed in C:\Python27, though you can change this when you’re running the installer. To add this directory to your path, you can type the following command into the command prompt in a DOS box:

set path=%path%;C:\python27
Typing an end-of-file character (Control-D on Unix, Control-Z on Windows) at the primary prompt causes the interpreter to exit with a zero exit status. If that doesn’t work, you can exit the interpreter by typing the following command: quit().

The interpreter’s line-editing features usually aren’t very sophisticated. On Unix, whoever installed the interpreter may have enabled support for the GNU readline library, which adds more elaborate interactive editing and history features. Perhaps the quickest check to see whether command line editing is supported is typing Control-P to the first Python prompt you get. If it beeps, you have command line editing; see Appendix Interactive Input Editing and History Substitution for an introduction to the keys. If nothing appears to happen, or if ^P is echoed, command line editing isn’t available; you’ll only be able to use backspace to remove characters from the current line.

The interpreter operates somewhat like the Unix shell: when called with standard input connected to a tty device, it reads and executes commands interactively; when called with a file name argument or with a file as standard input, it reads and executes a script from that file.

A second way of starting the interpreter is python -c command [arg] ..., which executes the statement(s) in command, analogous to the shell’s -c option. Since Python statements often contain spaces or other characters that are special to the shell, it is usually advised to quote command in its entirety with single quotes.

Some Python modules are also useful as scripts. These can be invoked using python -m module [arg] ..., which executes the source file for module as if you had spelled out its full name on the command line.

When a script file is used, it is sometimes useful to be able to run the script and enter interactive mode afterwards. This can be done by passing -i before the script.

All command-line options are described in Command line and environment.</p>
    <button ><a href="#pagetwo" data-transition="slide">Part 2</a></button>
  </div>

  <div data-role="footer" style="bottom:20px;background-color:#333; color:white;">
    <h1>Footer Text</h1>
  </div>
</div> 

<div data-role="page" id="pagetwo">
  <div data-role="header" style="background-color:#333; color:white;">
    <h1>Chapter 1.2.0</h1>
  </div>

  <div data-role="main" class="ui-content" >
    <p>Click on the link to see the slide effect REVERSED (slides to the previous page from left to right).</p>
     <button ><a href="#pagethree" data-transition="slide">Part3</a> </button >
	 <button ><a href="#pageone" data-transition="slide" data-direction="reverse">Back</a> </button >
  </div>

  <div data-role="footer">
    <h1>Footer Text</h1>
  </div>
</div> 

<div data-role="page" id="pagethree">
  <div data-role="header" style="background-color:#333; color:white;">
    <h1>Chapter 1.3.0</h1>
  </div>

  <div data-role="main" class="ui-content" >
    <p>Click on the link to see the slide effect REVERSED (slides to the previous page from left to right).</p>
     <button ><a href="#pageone" data-transition="slide" data-direction="reverse">Part3</a> </button >
	 <button ><a href="#pagetwo" data-transition="slide" data-direction="reverse">Back</a> </button >
  </div>

  <div data-role="footer">
    <h1>Footer Text</h1>
  </div>
</div> 
</body>
</html>