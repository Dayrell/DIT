
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Leaderboard</title>
	<ul>
			  <li><a  href="home.php">Home</a></li>
			  <li><a  href="profile.php">Profile</a></li>
			  <li><a  href="tutorial.php">Tutorial</a></li>
			  <li><a  href="index.php">Quiz</a></li>
			  <li><a class="active" href="leaderboard.php">Leaderboard</a></li>
			  <li><a href="main_forum.php">Forums</a></li>
			  <li style="float:right"><a href="login.php">Log Out</a></li>
			  <li style="float:right"><a href="#about">Sign Up</a></li>
			</ul>
			
</head>
<body background='plain.jpg'>
</body>
</html>


<?php
echo "<div id='leaderboard'>
<table align='center'style='border: solid 1px black;text-align:center;border-radius: 
25px;background-color:#cccccc';position:absolute; overflow: scroll;></div>";
echo "<tr style='border-radius: 
25px;'><th>Id</th><th>Username</th><th>Percentage</th></tr>";
echo "<h5 class='leader'> LEADERBOARD</h1>";
class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id,username,percentage FROM quiz_takers ORDER BY percentage DESC"); 
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";


?>

