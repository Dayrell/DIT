
<?php
	Session_start();
	$_SESSION['admin'] = "admin";
	$username = $_POST['username'];
	$userpass = $_POST['password'];
	
	
	if($username && $userpass)
	{
		$connect = mysql_connect("localhost", "root", "") or die ("Could not connect");
		mysql_select_db("test") or die ("Couldn't find Database");
		
		$query = mysql_query("SELECT * FROM admin WHERE username='$username'");
		
		$numrows = mysql_num_rows($query);
		if($numrows!=0)
		{
			while ($row = mysql_fetch_assoc($query))
			{
				$dbusername = $row['username'];
				$dbpassword = $row['password'];
			}
			if($username==$dbusername && $userpass==$dbpassword)
			{
				include('homeadmin.php');
				$_SESSION['username'] =$dbusername;
			}
			else
			{
				include('adminindex.php');
				echo '<span style="font-size:20px;color:red;margin-right:500px;float:right;"><b><u><br>INCORRECT PASSWORD</br></b></u></span>';
			}
		}
		else
		{
			include('adminindex.php');
			echo '<span style="font-size:20px;color:red;margin-right:500px;float:right;"><b><u><br>USER NOT FOUND</br></b></u></span>';
		}
		echo $numrows;
	}
?>