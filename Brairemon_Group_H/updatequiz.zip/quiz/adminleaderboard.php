<?php 
if(isset($_POST['reset']) && $_POST['reset'] != ""){
	$reset = preg_replace('/^[a-z]/', "", $_POST['reset']);
	require_once("scripts/connect_db.php");
	mysql_query("TRUNCATE TABLE quiz_takers")or die(mysql_error());
	$sql1 = mysql_query("SELECT id FROM quiz_takers LIMIT 1")or die(mysql_error());
	$numUsers = mysql_num_rows($sql1);
		if($numUsers> 0){
		echo "Sorry, there was a problem reseting the quiz. Please try again later.";
		exit();
	}else{
		echo "Thanks! The quiz has now been reset back to 0 questions.";
		exit();
	}
}
?>

<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Leaderboard</title>
	<ul>
			  <li><a  href="home.php">Home</a></li>
			  <li><a  href="profile.php">Profile</a></li>
			  <li><a  href="tutorial.php">Tutorial</a></li>
			  <li><a  href="index.php">Quiz</a></li>
			  <li><a class="active" href="leaderboard.php">Leaderboard</a></li>
			  <li><a href="main_forum.php">Forums</a></li>
			  <li style="float:right"><a href="login.php">Log Out</a></li>
			  <li style="float:right"><a href="#about">Sign Up</a></li>
			</ul>
			<script>
function resetQuiz(){
	var x = new XMLHttpRequest();
			var url = "adminleaderboard.php";
			var vars = 'reset=yes';
			x.open("POST", url, true);
			x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			x.onreadystatechange = function() {
		if(x.readyState == 4 && x.status == 200) {
			document.getElementById("resetBtn").innerHTML = x.responseText;
			
	}
}
x.send(vars);
document.getElementById("resetBtn").innerHTML = "processing...";
	
}
</script>
</head>

<body >
	<span id="resetBtn"><button onclick="resetQuiz()">Reset Users</button></span>
</body>
</html>

<?php
echo "<div id='leaderboard'>
<table align='center'style='border: solid 1px black;text-align:center;border-radius: 
25px;background-color:#cccccc';position:absolute; overflow: scroll;></div>";
echo "<tr><th>Id</th><th>Username</th><th>Percentage</th></tr>";
echo "<h5 class='leader'> LEADERBOARD</h1>";
class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id,username,percentage FROM quiz_takers ORDER BY percentage DESC"); 
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";


?>
