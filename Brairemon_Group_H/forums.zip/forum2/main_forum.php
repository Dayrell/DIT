<?php
	include 'header.php';
	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="myforum"; // Database name 
	$tbl_name="fquestions"; // Table name 
	 
	// Connect to server and select database.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");

	$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
	// OREDER BY id DESC is order result by descending

	$result=mysql_query($sql);
?>
<head>
	<title>Forum</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<table class="table table-striped">
			<thead>
				<tr>
					<th class="text-center">Topic</th>
					<th class="text-center">Views</th>
					<th class="text-center">Reply</th>
					<th class="text-center">Date/Time</th>
				</tr>

			<?php

			// Start looping table row
			while($rows = mysql_fetch_array($result)){
			?>
			<tbody>
				<tr>
					<td class="text-center"><a href="view_topic.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['topic']; ?></a><BR></td>
					<td class="text-center"><?php echo $rows['view']; ?></td>
					<td class="text-center"><?php echo $rows['reply']; ?></td>
					<td class="text-center"><?php echo $rows['datetime']; ?></td>
				</tr>

			<?php
			// Exit looping and close connection 
			}
			mysql_close();
			?>
				<tr>
					<td colspan="5" class="text-right"><a href="new_topic.php" class="btn btn-primary"><strong>Create New Topic</strong> </a></td>
				</tr>
			<tbody>
		</table>
	</div>
</body>
<?php
	include 'footer.php';
?>