<head>
	<title>View Topic</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<?php
	include 'header.php';
	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="myforum"; // Database name 
	$tbl_name="fquestions"; // Table name 

	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");

	// get value of id that sent from address bar 
	$id=$_GET['id'];
	$sql="SELECT * FROM $tbl_name WHERE id='$id'";
	$result=mysql_query($sql);
	$rows=mysql_fetch_array($result);
?>
	<div class="container">
			<table class="table table-striped">
					<td width="15%" class="text-center"><strong>
						<?php echo $rows['name'];?></strong>
						</BR>
						<small>
						<?php echo $rows['datetime']; ?></small>
					</td>
					<td class="info">
							<strong style="font-size: 30px;"><?php echo $rows['topic']; ?></strong>
							</BR>
							<?php echo $rows['detail']; ?>
					</td>

			</table>
		<?php

			$tbl_name2="fanswer"; // Switch to table "forum_answer"
			$sql2="SELECT * FROM $tbl_name2 WHERE question_id='$id'";
			$result2=mysql_query($sql2);
			while($rows=mysql_fetch_array($result2)){
		?>
		<table class="table table-bordered">
			<td width="15%" class="text-center"><strong>
				<?php echo $rows['a_name']; ?></strong>
				</BR>
				<small>
				<?php echo $rows['a_datetime']; ?>
				</small></td>
			<td class="success">
				<?php echo $rows['a_answer']; ?>
			</td>
		</table>
		<?php
			}
			$sql3="SELECT view FROM $tbl_name WHERE id='$id'";
			$result3=mysql_query($sql3);
			$rows=mysql_fetch_array($result3);
			$view=$rows['view'];

			// if have no counter value set counter = 1
			if(empty($view)){
				$view=0;
				$sql4="INSERT INTO $tbl_name(view) VALUES('$view') WHERE id='$id'";
				$result4=mysql_query($sql4);
			}

			// count more value
			$addview=$view+1;
			$sql5="update $tbl_name set view='$addview' WHERE id='$id'";
			$result5=mysql_query($sql5);
			mysql_close();
			
		?>
		<BR>
		<form name="form1" method="post" action="add_answer.php">
			<table class="table table-condensed">
				<tr>
					<td>Placeholder Name</td>
					<td><input name="a_name" type="text" id="a_name"></td>
				</tr>
				<tr>
					<td>Placeholder Email</td>
					<td><input name="a_email" type="text" id="a_email"></td>
				</tr>
				<tr>
					<td>Answer</td>
					<td><textarea name="a_answer" id="a_answer"></textarea></td>
				</tr>
				<tr>
					<td><input name="id" type="hidden" value="<?php echo $id; ?>"></td>
					<td><input type="submit" name="Submit" value="Reply"> <input type="reset" name="Submit2" value="Reset"></td>
				</tr>
			</table>
		</form>
	</div>
	<?php
		include 'footer.php';
	?>