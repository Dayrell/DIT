<html>
<head>
    <title>Forum</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
<h1>E-Learning Tool Forum</h1>
    <div id="wrapper">
    <div id="menu">
        <a class="item" href="/forum2/main_forum.php">Forum</a> -
        <a class="item" href="/forum2/">Placeholder 1</a> -
        <a class="item" href="/forum2/">Placeholder 2</a> -
		<a class="item" href="/forum2/">Placeholder 3</a> -
		<a class="item" href="/forum2/">Placeholder 4</a>
         
        <div id="userbar">
        <!--<?php
				if($_SESSION['signed_in'])
				{
					echo 'Hello' . $_SESSION['username'] . '. Not you? <a href="signout.php">Sign out</a>';
				}
				else
				{
					echo '<a href="signin.php">Sign in</a> or <a href="signup.php">create an account</a>.';
				}
			?>-->
		</div>
        <div id="content">
		</BR>
		</BR>