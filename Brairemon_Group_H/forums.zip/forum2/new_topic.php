<html>
	<head>
		<title>New Topic</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<?php
		include 'header.php';
		$host="localhost"; // Host name 
		$username="root"; // Mysql username 
		$password=""; // Mysql password 
		$db_name="myforum"; // Database name 
		$tbl_name="fquestions"; // Table name 

		// Connect to server and select databse.
		mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
		mysql_select_db("$db_name")or die("cannot select DB");
	?>
	<body>
		<form id="form1" name="form1" method="post" action="add_new_topic.php">
		<table class="table table-default>	
					<th colspan="3" class="info"><strong>Create New Topic</strong> </th>
					<tr>
						<td><strong>Topic</strong></td>
						<td>:</td>
						<td><input name="topic" type="text" id="topic" size="50" /></td>
					</tr>
					<tr>
						<td valign="top"><strong>Detail</strong></td>
						<td valign="top">:</td>
						<td><textarea name="detail" cols="50" rows="3" id="detail"></textarea></td>
					</tr>
					<tr>
						<td><strong>Placeholder Name</strong></td>
						<td>:</td>
						<td><input name="name" type="text" id="name" size="50" /></td>
					</tr>
					<tr>
						<td><strong>Placeholder Email</strong></td>
						<td>:</td>
						<td><input name="email" type="text" id="email" size="50" /></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td><input type="submit" name="Submit" value="Submit" /> 
						<input type="reset" name="Submit2" value="Reset" /></td>
					</tr>
		</table>
		</form>
		<?php
			include 'footer.php';
		?>
	</body>
</html>