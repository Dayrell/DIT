
<?php
	
	session_start();
	$username = $_POST['username'];
	$userpass = $_POST['password'];
	
	
	if($username && $userpass)
	{
		$connect = mysql_connect("localhost", "root", "") or die ("Could not connect");
		mysql_select_db("test") or die ("Couldn't find Database");
		
		$query = mysql_query("SELECT * FROM users WHERE username='$username'");
		
		$numrows = mysql_num_rows($query);
		if($numrows!=0)
		{
			while ($row = mysql_fetch_assoc($query))
			{
				$dbusername = $row['username'];
				$dbpassword = $row['userpass'];
			}
			if($username==$dbusername && $userpass==$dbpassword)
			{
				include('home.php');
				$_SESSION['username'] =$dbusername;
			}
			else
			{
				include('login.php');
				echo '<span style="font-size:20px;color:red;margin-right:500px;float:right;"><b><u><br>INCORRECT PASSWORD</br></b></u></span>';
			}
		}
		else
		{
			include('login.php');
			echo '<span style="font-size:20px;color:red;margin-right:500px;float:right;"><b><u><br>USER NOT FOUND</br></b></u></span>';
		}
		echo $numrows;
	}
	else
	{
		include('login.php');
		print "<font color='red'> hello</font>";
	}
?>