
<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>login</title>
</head>
<body background="login.png">

<form id="login" action="logdb.php" method="post" accept-charset="utf-8" >
			<ul id='log' style="background-color:#00b8eb;">
				<li style="width:100px">
					<input type="text" name="username" placeholder="Student Number" required>
				</li>
				<li style="margin-left:100px">
					<input type="text" name="password" placeholder="Password" required></li>
				<li style="margin-left:14px; padding:0px; border:none;">
					<input type="submit" value="Login">
				</li>
			</ul>
		</form>
</body>
</html>